from django.db import models

# Create your models here.
class Student_info(models.Model):
    stud_name = models.CharField(max_length=64)
    stud_age = models.IntegerField()
    course = models.CharField()
    stud_type = models.CharField()
    dob = models.DateField()

class Parent_info():
    mother_name = models.CharField(max_length=64)
    father_name = models.CharField(max_length=64)
    mother_contact = models.IntegerField()
    father_contact = models.IntegerField()
    guardian_name = models.CharField(max_length=64)
    guardian_contact = models.IntegerField()
    