from django import forms    
from .models import Student_info, Parent_info

class Student_infoForm(forms.ModelForm):
    class Meta:
        model = Student_info
        fields = '__all__'

class Parent_infoForm(forms.ModelForm):
    class Meta:
        model = Parent_info
        fields = '__all__'
