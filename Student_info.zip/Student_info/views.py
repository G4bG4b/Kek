from django.shortcuts import render, redirect
from .forms import Parent_infoForm, Student_infoForm

# Parent Form View
def parent_form_view(request):
    if request.method == "POST":
        form = Parent_infoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = Parent_infoForm()

    return render(request, 'parent_form.html', {'form': form})


# Student Form View
def student_form_view(request):
    if request.method == "POST":
        form = Student_infoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = Student_infoForm()

    return render(request, 'student_form.html', {'form': form})


def success(request):
    return render(request, "success.html")




