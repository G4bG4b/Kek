from django.urls import path
from . import views

urlpatterns = [
    path('parent/', views.parent_form_view, name='parent_form'),
    path('student/', views.student_form_view, name='student_form'),
    path('success/', views.success, name='success'),
]